import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

export default function AddForm() {
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    
    <div className="AddForm">
      <Button variant="outlined" onClick={handleClickOpen}>Add </Button>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Add</DialogTitle>
        <DialogContent sx={{backgroundColor:' #273D49CC'}}>
          
          <TextField Style={{backgroundColor:'white'}}
            autoFocus
            margin="dense"
           // id="name"
            label="Business Code"
            type="text"
            defaultValue="Business Code"
            variant="standard"
          />
           <TextField
            autoFocus
            margin="dense"
           // id="name"
            label="Customer Number"
            type="text"
            defaultValue="Customer Number"
            variant="standard"
          />
          <TextField
            autoFocus
            margin="dense"
           // id="name"
            label="Clear Date"
            type="date"
            defaultValue="Clear Date"
            variant="standard"
          />
          <TextField
            autoFocus
            margin="dense"
           // id="name"
            label="Business year"
            type="text"
            defaultValue="Business year"
            variant="standard"
          />
          <TextField
            autoFocus
            margin="dense"
           // id="name"
            label="Document ID"
            type="text"
            defaultValue="Document ID"
            variant="standard"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleClose}>Subscribe</Button>
        </DialogActions>
      </Dialog>
    </div>
    
  );
}