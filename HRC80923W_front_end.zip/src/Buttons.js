import React from 'react'
import Box from '@mui/material/Box';

import Button from '@mui/material/Button';
import ButtonGroup from '@mui/material/ButtonGroup';
import AddForm from './AddForm';
import EditForm from './EditForm';
import Delete from './Delete';

function Buttons(){
    return(
       
        <div ClassName="buttons">
            
        <div ClassName="buttonsleft">    
        <ButtonGroup size="large" variant="outlined" aria-label="outlined button group"
        sx={{fontColor: "white"}}>
        <Button>PREDICT</Button>
        <Button>ANALYTICS VIEW</Button>
        <Button>ADVANCE SEARCH</Button>
        <div className="search">
            <input style={{fontSize : '20px', background : 'none', border: 'none' , boxShadow: 'none', borderStyle: 'hidden', height: 'fitContent'}} placeholder='Search by invoice' name="search" />
        </div>
        
        <AddForm/>
        <EditForm/>
        <Delete/>
        
        </ButtonGroup>
        </div>
      
       
        </div>
       
    )
}
export default Buttons;