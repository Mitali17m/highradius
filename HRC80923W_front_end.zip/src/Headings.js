import React from 'react'

function Headings() {
  return (
    <div className="headings">
        <img src="Group.png" alt="" className="Inv"/>
        <div className="img1">
            <img src="logohighradius.png"/>
        </div>
        
        <div style={{width : '320px'}}></div>
    </div>
  )
}

export default Headings