import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

import Buttons from './Buttons';
function List() {
    
    return(
        
        <div id="list">

            <Buttons/>

            <div id="tab_div">
                <table className="table" id="whole">
                    <tbody id="MyTable">
                        <thead className="head">
                            <th id="Ch_box" style={{width: '10px' , backgroundColor: 'transparent'}}><input type="checkbox" name="" value="" /></th>
                            <th>sl_no</th>
                            <th>business code</th>
                            <th>cust number </th>
                            <th>clear date</th>
                            <th>buisness year</th>
                            <th>doc id</th>
                            <th>posting date</th>
                            <th>document create date</th>
                            <th>due in date</th>
                            <th>invoice currency</th>
                            <th>document type</th>
                            <th>posting id</th>
                            <th>total open amount</th>
                            <th>baseline create date</th>
                            <th>cust payment terms</th>
                            <th>invoice id</th>
                        </thead>
                    </tbody>
                </table>
            </div>
</div>
    )
}


export default List