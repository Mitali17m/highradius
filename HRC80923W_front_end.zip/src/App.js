import './App.css';
import Headings from './Headings.js';
import List from './List';
import Buttons from './Buttons.js';
import AddForm from './AddForm';
import Footer from './Footer';
import { MDBCol, MDBContainer, MDBRow, MDBFooter } from "mdbreact";
function App() {
  return (
    <div className="App">
      <Headings/>
      <List></List>
    
      </div>
    
      )
      }

export default App;
