import com.google.gson.Gson;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Add
 */
@WebServlet("/Add")
public class Add extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Add() {
    	super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			HashMap<Object, Object> Response = new HashMap<Object, Object>();
			int sl_no = Integer.parseInt(request.getParameter("sl_no"));
			String business_code = request.getParameter("business_code");
			int cust_number = Integer.parseInt(request.getParameter("cust_number"));
			String clear_date = request.getParameter("clear_date");
			String buisness_year = request.getParameter("buisness_year");
			String doc_id = request.getParameter("doc_id");
			String posting_date = request.getParameter("posting_date");
			String document_create_date = request.getParameter("document_create_date");
			String due_in_date = request.getParameter("due_in_date");
			String invoice_currency = request.getParameter("invoice_currency");
			String document_type = request.getParameter("document_type");
			float posting_id = Float.parseFloat(request.getParameter("posting_id"));
			float total_open_amount = Float.parseFloat(request.getParameter("total_open_amount"));
			String baseline_create_date = request.getParameter("baseline_clear_date");
			String cust_payment_terms = request.getParameter("cust_payment_terms");
			float invoice_id = Float.parseFloat(request.getParameter("invoice_id"));
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/grey_goose", "root", "8803243545");
			
			String sql = "INSERT INTO winter_internship (sl_no, business_code, cust_number, clear_date, buisness_year, doc_id, posting_date,document_create_date, due_in_date, invoice_currency, document_type, posting_id, total_open_amount, baseline_create_date, cust_payment_terms,invoice_id)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1, sl_no);
			preparedStatement.setString(2, business_code);
			preparedStatement.setInt(3, cust_number);
			preparedStatement.setString(4, clear_date);
			preparedStatement.setString(5, buisness_year);
			preparedStatement.setString(6, doc_id);
			preparedStatement.setString(7, posting_date);
			preparedStatement.setString(8, document_create_date);
			preparedStatement.setString(9, due_in_date);
			preparedStatement.setString(10, invoice_currency);
			preparedStatement.setString(11, document_type);
			preparedStatement.setFloat(12, posting_id);
			preparedStatement.setFloat(13, total_open_amount);
			preparedStatement.setString(14, baseline_create_date);
			preparedStatement.setString(15, cust_payment_terms);
			preparedStatement.setFloat(16, invoice_id);
			
			if(preparedStatement.executeUpdate() > 0)
			{
				Response.put("status", true);
			} 
			else 
			{
				Response.put("status", false);
			}
			
			Gson gson = new Gson();
			String ResponseJSON = gson.toJson(Response);
			response.setHeader("Access-Control-Allow-Origin", "*");
			response.getWriter().append(ResponseJSON);
			System.out.println(ResponseJSON);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}