import java.sql.Date;

public class Pojo {
	public int sl_no;
	public String business_code;
	public String business_name;
	public int cust_number;
	public String name_customer;
	public String clear_date;
	public String buisness_year;
	public String doc_id;
	public String posting_date;
	public String document_create_date;
	public String document_create_date1;
	public String due_in_date;
	public String invoice_currency;
	public String document_type;
	public float posting_id;
	public String area_business;
	public float total_open_amount;
	public String baseline_create_date;
	public String cust_payment_terms;
	public float invoice_id;
	public boolean isOpen;
	public String predicted;
	public boolean is_deleted;
	
	public Pojo(int sl_no, String business_code, int cust_number, String clear_date, String buisness_year, String doc_id,
			String posting_date, String document_create_date, String due_in_date, String invoice_currency,
			String document_type, float posting_id, float total_open_amount, String baseline_create_date,
			String cust_payment_terms, float invoice_id) {
		super();
		this.sl_no = sl_no;
		this.business_code = business_code;
		this.cust_number = cust_number;
		this.clear_date = clear_date;
		this.buisness_year = buisness_year;
		this.doc_id = doc_id;
		this.posting_date = posting_date;
		this.document_create_date = document_create_date;
		this.due_in_date = due_in_date;
		this.invoice_currency = invoice_currency;
		this.document_type = document_type;
		this.posting_id = posting_id;
		this.total_open_amount = total_open_amount;
		this.baseline_create_date = baseline_create_date;
		this.cust_payment_terms = cust_payment_terms;
		this.invoice_id = invoice_id;
	}

	
	
	public Pojo()
	{
		
	}

	
	
	

	
}