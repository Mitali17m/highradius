import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * Servlet implementation class AdvSearch
 */
@WebServlet("/AdvSearch")
public class Advancesearch extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Advancesearch() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			HashMap<Object, Object> Response = new HashMap<Object, Object>();
			ArrayList<Pojo> Invoice = new ArrayList<Pojo>();
			String doc_id = request.getParameter("doc_id");
			float invoice_id = Float.parseFloat(request.getParameter("invoice_id"));
			int cust_number = Integer.parseInt(request.getParameter("cust_number"));
			String buisness_year = request.getParameter("buisness_year");
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/grey_goose", "root", "8803243545");
			
			String sql = "SELECT * FROM winter_internship WHERE (doc_id = ? AND invoice_id = ? AND cust_number = ? AND buisness_year = ?)";
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, doc_id);
			preparedStatement.setFloat(2, invoice_id);
			preparedStatement.setInt(3, cust_number);
			preparedStatement.setString(4, buisness_year);
			ResultSet rs = preparedStatement.executeQuery();
			
			while(rs.next())
			{
				Pojo obj = new Pojo(rs.getInt("sl_no"),rs.getString("business_code"),rs.getInt("cust_number"),rs.getString("clear_date"),rs.getString("buisness_year"),rs.getString("doc_id"),rs.getString("posting_date"),rs.getString("document_create_date"),rs.getString("due_in_date"),rs.getString("invoice_currency"),rs.getString("documnet_type"),rs.getFloat("posting_id"),rs.getFloat("total_open_amount"),rs.getString("baseline_create_date"),rs.getString("cust_payment_terms"),rs.getFloat("invoice_id"));
				Invoice.add(obj);
			}
			
			if(preparedStatement.executeUpdate()>0)
			{
				Response.put("found", true);
			} else {
				Response.put("found", false);
			}
			
			PrintWriter out = response.getWriter();
			String Responsejson = new Gson().toJson(Invoice);
			response.setHeader("Access-Control-Allow-Origin", "*");
			out.print(Responsejson);
			
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}